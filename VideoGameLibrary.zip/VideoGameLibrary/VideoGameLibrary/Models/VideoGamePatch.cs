﻿namespace VideoGameLibrary.Models
{
    public class VideoGamePatch
    {
         public required string Genres { get; set; }
    }
}
